# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
import json

class TC_DevControl(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("DeviceControl2")
        
        
        #the id in managed_device_info_tbl  
        self.zwaveSmartsocket_id=""
        self.zwaveLight_id="56bab4b6-6083-4a01-bb6e-ab233e429b50"
        self.zwaveDoorLockSchlage_id=""
        self.zwaveDoorLockKwikset_id="54672307-e061-4a13-a8d7-53c4406f21a8"
        self.zwaveDrape_id="9b6e8170-5cd4-4ee4-8580-0f0417921b40"
        self.zwaveSoundbar_id=""
        self.zwaveBinarySwitch_id="77766f78-09fb-4ac2-9714-5860eb471c9b" #203bb426-b5b5-43db-aaa9-488af22d02b5
        self.zwaveMultiLevelSwitch_id="77766f78-09fb-4ac2-9714-5860eb471c9b"
        self.zwaveThermostat_id=""
        self.tv_id=""
        self.waterSensor_id=""
#         self.zwaveEverspringSensor_id,
#         self.zwaveMultiSensor_id,
        

        self.long_string_id="123123i41o34dkfrqlekrjoqernqojr4q2o3j5oq2345jo234523o5j23o45j23ojfioq4hj523o45hj2nhtghoq24h2o345o9**(()";
        self.wrong_string_id1 = "d876cdc8-c582-4838-b065-d0eddddddddddd7frtrrrrrrrrrrrr8a7e75";
        self.wrong_string_id2 = "我爱中国我爱中国";
        self.wrong_string_id3 = "개발개발개발개발개발개발개발개발";
        self.wrong_string_id4 = "さまざまさまざまさまざま";
        self.null_string_id=""
        
        self.wrong_string_id_list=[self.long_string_id,self.wrong_string_id1,self.wrong_string_id2,self.wrong_string_id3,self.wrong_string_id4,self.null_string_id]
        
    def setUp(self):
        pass
    
    
    '''
    #=============================Binary Switch===================================
    def FN_DC_BinarySwitch_001(self):
        self.logger.info("FN_DC_BinarySwitch_001 :: test Binary Switch powerstatus----normal")
        finalValue=True
        for powerOperation in ["on"]: #,"Off"
            res,resp=self.sendRst.setDeviceStatus(self.zwaveBinarySwitch_id,"Light",powerOperation) #Smart_Socket
            self.logger.info(res.status)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveBinarySwitch_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getStatus=getRes["Operation"]["power"]
#                     if(getStatus != powerOperation):
#                         finalValue=False
#                         self.logger.info("get Binary Switch:"+getStatus +"is not equal with set light :"+powerOperation)
#                 else:
#                     finalValue=False
#                     self.logger.info("get Binary Switch:"+powerOperation +"---failure")
            else:
                finalValue=False
                self.logger.info("set Binary Switch:"+powerOperation +"----failure")
        self.assertTrue(finalValue)
     
      
    '''
    #=============================Multi-Level Switch  ===================================
    
        
    def FN_DC_MLSwitch_001(self):
        self.logger.info("FN_DC_MLSwitch_001 :: test Multi-Level Switch  dimming level----normal")
        finalValue=True
        for level in ["0"]: #0,50,99   0~255   max int=-2147483648－－2147483647
            res,resp=self.sendRst.setDeviceStatus(self.zwaveMultiLevelSwitch_id,"Light",level)
            self.logger.info(res.status)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveMultiLevelSwitch_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getLevel=getRes["Light"]["level"]
#                     if(getLevel != level):
#                         finalValue=False
#                         self.logger.info("get Multi-Level Switch dimming level:"+getLevel +"is not equal with set level :"+level)
#                 else:
#                     finalValue=False
#                     self.logger.info("get Multi-Level Switch dimming level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set light:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
     
    
    '''
    #=============================door lock===================================
    def FN_DC_DoorLock_001(self):
        self.logger.info("FN_DC_DoorLock_001 :: test door lock ----normal")
        finalValue=True
        for doorOperation in ["Lock"]: #,"Unlock"  Lock
            res,resp=self.sendRst.setDeviceStatus(self.zwaveDoorLockKwikset_id,"Door_Lock",doorOperation) 
            self.logger.info(res.status)
            self.logger.info(resp)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveDoorLockKwikset_id)
#                 print getres.status
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getStatus=getRes["Operation"]["lock"]
#                     if(getStatus != doorOperation):
#                         finalValue=False
#                         self.logger.info("get doorLck:"+getStatus +"is not equal with set doorLock :"+doorOperation)
#                 else:
#                     finalValue=False
#                     self.logger.info("get doorLock:"+doorOperation +"----failure")
            else:
                finalValue=False
                self.logger.info("set doorLock:"+doorOperation +"-----failure")
        self.assertTrue(finalValue)
            
    
    #=============================drape===================================
    def FN_DC_Drape_001(self):
        self.logger.info("FN_DC_Drape_001 :: test drape ----normal")
        finalValue=True
        for level in ["255"]: #0,50,99   0~255   max int=-2147483648－－2147483647
            res,resp=self.sendRst.setDeviceStatus(self.zwaveDrape_id,"Basic_Drapery",level)
            self.logger.info(res.status)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveDrape_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getLevel=getRes["Light"]["level"]
#                     if(getLevel != level):
#                         finalValue=False
#                         self.logger.info("get Multi-Level Switch dimming level:"+getLevel +"is not equal with set level :"+level)
#                 else:
#                     finalValue=False
#                     self.logger.info("get Multi-Level Switch dimming level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set drape:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
    
        
    #=============================Light===================================
        
     
       
     
    def FN_DC_Light_006(self):
        self.logger.info("FN_Device_Control_018 :: test Light dimming level----normal")
        finalValue=True
        for level in ["45"]:
            res,resp=self.sendRst.setDeviceStatus(self.zwaveLight_id,"Light",level)
            self.logger.info(res.status)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveLight_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getLevel=getRes["Light"]["level"]
#                     if(getLevel != level):
#                         finalValue=False
#                         self.logger.info("get dimming level:"+getLevel +"is not equal with set level :"+level)
#                 else:
#                     finalValue=False
#                     self.logger.info("get light dimming level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set light:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
        
     
         
     
    def FN_DC_Light_007(self):
        self.logger.info("FN_DC_Light_007 :: test Binary Light powerstatus----normal")
        finalValue=True
        for powerOperation in ["off"]: #,"Off"
            res,resp=self.sendRst.setDeviceStatus(self.zwaveLight_id,"Light",powerOperation)
            self.logger.info(res.status)
            if(res.status == 200):
                finalValue=True
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveLight_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getStatus=getRes["Operation"]["power"]
#                     if(getStatus != powerOperation):
#                         finalValue=False
#                         self.logger.info("get Binary Switch:"+getStatus +"is not equal with set light :"+powerOperation)
#                 else:
#                     finalValue=False
#                     self.logger.info("get Binary Switch:"+powerOperation +"---failure")
            else:
                finalValue=False
                self.logger.info("set Binary Switch:"+powerOperation +"----failure")
        self.assertTrue(finalValue)
   
    
    #=============================smart sokcet===================================
    def FN_DC_SmartSocket_001(self):
        self.logger.info("FN_Device_Control_005 :: test smart sokcet powerstatus ----normal")
        finalValue=True
        for powerOperation in ["On","Off"]:
            data=self.devCtrlInfo.putpowerStatuslInfo(powerOperation)
            res,resp=self.sendRst.setPowerStatus(self.zwaveSmartsocket_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveSmartsocket_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getStatus=getRes["Operation"]["power"]
                    if(getStatus != powerOperation):
                        finalValue=False
                        self.logger.info("get smart sokcet:"+getStatus +"is not equal with set smart sokcet :"+powerOperation)
                else:
                    finalValue=False
                    self.logger.info("get smart sokcet:"+powerOperation +"failure")
            else:
                finalValue=False
                self.logger.info("set smart sokcet:"+powerOperation +"failure")
        self.assertTrue(finalValue, "set failue")
            
            
            
    #=============================Thermostat (Thermostat)===================================
    def FN_DC_ThermostatTemperature_001(self):
        self.logger.info("FN_DC_ThermostatTemperature_001 :: test Thermostat Temperature ----normal")
        finalValue=True
        for desired in [0,50,100]:
            data=self.devCtrlInfo.puttemperatureInfo(desired)
            res,resp=self.sendRst.setTemperature(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getDesireds=getRes["desired"]
                    if(getDesireds != desired):
                        finalValue=False
                        self.logger.info("get Temperature:"+getDesireds +"is not equal with set Temperature :"+desired)
                else:
                    finalValue=False
                    self.logger.info("get Temperature:"+desired +"failure")
            else:
                finalValue=False
                self.logger.info("set Temperature:"+desired +"failure")
        self.assertTrue(finalValue, "set failue")
        
        
        
    def FN_DC_ThermostatWindDirection_001(self):
        self.logger.info("FN_DC_ThermostatWindDirection_001 :: test Thermostat wind direction ----normal")
        finalValue=True
        for direction in ["auto"]:
            data=self.devCtrlInfo.putwindInfo_Direction(direction)
            res,resp=self.sendRst.setWind(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getDirection=getRes["direction"]
                    if(getDirection != direction):
                        finalValue=False
                        self.logger.info("get wind direction:"+getDirection +"is not equal with set wind :"+direction)
                else:
                    finalValue=False
                    self.logger.info("get wind direction:"+direction +"failure")
            else:
                finalValue=False
                self.logger.info("set wind direction:"+direction +"failure")
        self.assertTrue(finalValue, "set failue")
        
        
    def FN_DC_ThermostatWindSpeedLevel_001(self):
        self.logger.info("FN_DC_ThermostatWindSpeedLevel_001 :: test Thermostat wind speedLevel ----normal")
        finalValue=True
        for speedLevel in [1,20,100]:
            data=self.devCtrlInfo.putwindInfo_SpeedLevel(speedLevel)
            res,resp=self.sendRst.setWind(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getSpeedLevel=getRes["speedLevel"]
                    if(getSpeedLevel != speedLevel):
                        finalValue=False
                        self.logger.info("get wind speedLevel:"+getSpeedLevel +"is not equal with set wind :"+speedLevel)
                else:
                    finalValue=False
                    self.logger.info("get wind speedLevel:"+speedLevel +"failure")
            else:
                finalValue=False
                self.logger.info("set wind speedLevel:"+speedLevel +"failure")
        self.assertTrue(finalValue, "set failue")
    '''