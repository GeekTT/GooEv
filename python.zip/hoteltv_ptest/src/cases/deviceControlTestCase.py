# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
from deviceControlInfo import DeviceControlInfoClass
import json

class TC_DevControl(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("DeviceManager")
        self.devCtrlInfo=DeviceControlInfoClass()
        
        self.zwaveSmartsocket_id=""
        self.zwaveLight_id=""
        self.zwaveDoorLockSchlage_id=""
        self.zwaveDoorLockKwikset_id="da6b81fa-6a5f-4d2b-bfff-374d9b811ae1"
        self.zwaveDrape_id=""
        self.zwaveSoundbar_id=""
        self.zwaveBinarySwitch_id=""
        self.zwaveMultiLevelSwitch_id=""
        self.zwaveThermostat_id=""
        self.tv_id=""
        self.waterSensor_id=""
#         self.zwaveEverspringSensor_id,
#         self.zwaveMultiSensor_id,
        

        self.long_string_id="123123i41o34dkfrqlekrjoqernqojr4q2o3j5oq2345jo234523o5j23o45j23ojfioq4hj523o45hj2nhtghoq24h2o345o9**(()";
        self.wrong_string_id1 = "d876cdc8-c582-4838-b065-d0eddddddddddd7frtrrrrrrrrrrrr8a7e75";
        self.wrong_string_id2 = "我爱中国我爱中国";
        self.wrong_string_id3 = "개발개발개발개발개발개발개발개발";
        self.wrong_string_id4 = "さまざまさまざまさまざま";
        self.null_string_id=""
        
        self.wrong_string_id_list=[self.long_string_id,self.wrong_string_id1,self.wrong_string_id2,self.wrong_string_id3,self.wrong_string_id4,self.null_string_id]
        
    def setUp(self):
        pass
    
    
    '''
    #=============================Binary Switch===================================
    def FN_DC_BinarySwitch_001(self):
        self.logger.info("FN_DC_BinarySwitch_001 :: test Binary Switch powerstatus----normal")
        finalValue=True
        for powerOperation in ["On","Off"]:
            data=self.devCtrlInfo.putpowerStatuslInfo(powerOperation)
            res,resp=self.sendRst.setPowerStatus(self.zwaveBinarySwitch_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveBinarySwitch_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getStatus=getRes["Operation"]["power"]
                    if(getStatus != powerOperation):
                        finalValue=False
                        self.logger.info("get Binary Switch:"+getStatus +"is not equal with set light :"+powerOperation)
                else:
                    finalValue=False
                    self.logger.info("get Binary Switch:"+powerOperation +"failure")
            else:
                finalValue=False
                self.logger.info("set Binary Switch:"+powerOperation +"failure")
        self.assertTrue(finalValue, "set failue")
    '''  
        
    
    #=============================door lock===================================
    def FN_DC_DoorLock_001(self):
        self.logger.info("FN_DC_DoorLock_001 :: test door lock ----normal")
        finalValue=True
        for doorOperation in ["Lock"]: #,"Unlock"
            data=self.devCtrlInfo.putdoorLockInfo(doorOperation)
            print data
            res,resp=self.sendRst.setDoorLock(self.zwaveDoorLockKwikset_id,data) 
            self.logger.info(res.status)
#             if(res.status == 204):
#                 getres,getresp=self.sendRst.getDeviceStatus(self.zwaveDoorLockKwikset_id)
#                 if(getres.status==200):
#                     getRes=json.loads(getresp)
#                     getStatus=getRes["Operation"]["lock"]
#                     if(getStatus != doorOperation):
#                         finalValue=False
#                         self.logger.info("get doorLck:"+getStatus +"is not equal with set doorLock :"+doorOperation)
#                 else:
#                     finalValue=False
#                     self.logger.info("get doorLock:"+doorOperation +"----failure")
#             else:
            if(res.status != 204):
                finalValue=False
                self.logger.info("set doorLock:"+doorOperation +"-----failure")
        self.assertTrue(finalValue, "set failue")
            
    '''   
    #=============================drape===================================
    def FN_DC_Drape_001(self):
        self.logger.info("FN_DC_Drape_001 :: test drape ----normal")
        finalValue=True
        for level in [0,50,100]:  #set max int
            data=self.devCtrlInfo.putlevelInfo(level)
            res,resp=self.sendRst.setLevel(self.zwaveDrape_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveDrape_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getLevel=getRes["Operation"]["lock"]
                    if(getLevel != level):
                        finalValue=False
                        self.logger.info("get level:"+getLevel +"is not equal with set level :"+level)
                else:
                    finalValue=False
                    self.logger.info("get level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set level:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
    
            
            
    #=============================Light===================================
    def FN_DC_Light_001(self):
        self.logger.info("FN_Device_Control_015 :: test Light powerstatus----normal")
        finalValue=True
        for powerOperation in ["On","Off"]:
            data=self.devCtrlInfo.putpowerStatuslInfo(powerOperation)
            res,resp=self.sendRst.setPowerStatus(self.zwaveLight_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveLight_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getStatus=getRes["Operation"]["power"]
                    if(getStatus != powerOperation):
                        finalValue=False
                        self.logger.info("get light:"+getStatus +"is not equal with set light :"+powerOperation)
                else:
                    finalValue=False
                    self.logger.info("get light:"+powerOperation +"failure")
            else:
                finalValue=False
                self.logger.info("set light:"+powerOperation +"failure")
        self.assertTrue(finalValue, "set failue")
        
        
        
        
    def FN_DC_Light_006(self):
        self.logger.info("FN_Device_Control_018 :: test Light dimming level----normal")
        finalValue=True
        for level in [0,50,100]:
            data=self.devCtrlInfo.putDimmingLevel(level)
            res,resp=self.sendRst.setDimmingLevel(self.zwaveLight_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveLight_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getLevel=getRes["Light"]["level"]
                    if(getLevel != level):
                        finalValue=False
                        self.logger.info("get dimming level:"+getLevel +"is not equal with set level :"+level)
                else:
                    finalValue=False
                    self.logger.info("get light dimming level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set light:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
        
     
    #=============================Multi-Level Switch (Light) ===================================
    def FN_DC_MLSwithc_001(self):
        self.logger.info("FN_DC_MLSwithc_001 :: test Multi-Level Switch  dimming level----normal")
        finalValue=True
        for level in [0,50,100]:
            data=self.devCtrlInfo.putDimmingLevel(level)
            res,resp=self.sendRst.setDimmingLevel(self.zwaveMultiLevelSwitch_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveMultiLevelSwitch_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getLevel=getRes["Light"]["level"]
                    if(getLevel != level):
                        finalValue=False
                        self.logger.info("get Multi-Level Switch dimming level:"+getLevel +"is not equal with set level :"+level)
                else:
                    finalValue=False
                    self.logger.info("get Multi-Level Switch dimming level:"+level +"failure")
            else:
                finalValue=False
                self.logger.info("set light:"+level +"failure")
        self.assertTrue(finalValue, "set failue")
       
    #=============================smart sokcet===================================
    def FN_DC_SmartSocket_001(self):
        self.logger.info("FN_Device_Control_005 :: test smart sokcet powerstatus ----normal")
        finalValue=True
        for powerOperation in ["On","Off"]:
            data=self.devCtrlInfo.putpowerStatuslInfo(powerOperation)
            res,resp=self.sendRst.setPowerStatus(self.zwaveSmartsocket_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveSmartsocket_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getStatus=getRes["Operation"]["power"]
                    if(getStatus != powerOperation):
                        finalValue=False
                        self.logger.info("get smart sokcet:"+getStatus +"is not equal with set smart sokcet :"+powerOperation)
                else:
                    finalValue=False
                    self.logger.info("get smart sokcet:"+powerOperation +"failure")
            else:
                finalValue=False
                self.logger.info("set smart sokcet:"+powerOperation +"failure")
        self.assertTrue(finalValue, "set failue")
            
            
            
    #=============================Thermostat (Thermostat)===================================
    def FN_DC_ThermostatTemperature_001(self):
        self.logger.info("FN_DC_ThermostatTemperature_001 :: test Thermostat Temperature ----normal")
        finalValue=True
        for desired in [0,50,100]:
            data=self.devCtrlInfo.puttemperatureInfo(desired)
            res,resp=self.sendRst.setTemperature(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getDesireds=getRes["desired"]
                    if(getDesireds != desired):
                        finalValue=False
                        self.logger.info("get Temperature:"+getDesireds +"is not equal with set Temperature :"+desired)
                else:
                    finalValue=False
                    self.logger.info("get Temperature:"+desired +"failure")
            else:
                finalValue=False
                self.logger.info("set Temperature:"+desired +"failure")
        self.assertTrue(finalValue, "set failue")
        
        
        
    def FN_DC_ThermostatWindDirection_001(self):
        self.logger.info("FN_DC_ThermostatWindDirection_001 :: test Thermostat wind direction ----normal")
        finalValue=True
        for direction in ["auto"]:
            data=self.devCtrlInfo.putwindInfo_Direction(direction)
            res,resp=self.sendRst.setWind(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getDirection=getRes["direction"]
                    if(getDirection != direction):
                        finalValue=False
                        self.logger.info("get wind direction:"+getDirection +"is not equal with set wind :"+direction)
                else:
                    finalValue=False
                    self.logger.info("get wind direction:"+direction +"failure")
            else:
                finalValue=False
                self.logger.info("set wind direction:"+direction +"failure")
        self.assertTrue(finalValue, "set failue")
        
        
    def FN_DC_ThermostatWindSpeedLevel_001(self):
        self.logger.info("FN_DC_ThermostatWindSpeedLevel_001 :: test Thermostat wind speedLevel ----normal")
        finalValue=True
        for speedLevel in [1,20,100]:
            data=self.devCtrlInfo.putwindInfo_SpeedLevel(speedLevel)
            res,resp=self.sendRst.setWind(self.zwaveThermostat_id,data) 
            self.logger.info(res.status)
            if(res.status == 204):
                getres,getresp=self.sendRst.getDeviceStatus(self.zwaveThermostat_id)
                if(getres.status==200):
                    getRes=json.loads(getresp)
                    getSpeedLevel=getRes["speedLevel"]
                    if(getSpeedLevel != speedLevel):
                        finalValue=False
                        self.logger.info("get wind speedLevel:"+getSpeedLevel +"is not equal with set wind :"+speedLevel)
                else:
                    finalValue=False
                    self.logger.info("get wind speedLevel:"+speedLevel +"failure")
            else:
                finalValue=False
                self.logger.info("set wind speedLevel:"+speedLevel +"failure")
        self.assertTrue(finalValue, "set failue")
    '''