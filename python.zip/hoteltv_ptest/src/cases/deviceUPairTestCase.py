# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
import json

class TC_DevUPair(unittest.TestCase):
    
    lockStatusType=""
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("DeviceUPair")
        
#         self.zwaveSmartsocket_id,
        self.roomId="0004-99929c65-9401-4524-be09-b46c5cfabf40" 
        self.zwaveLight_id=""
        self.zwaveDoorLockSchlage_id=""
        self.zwaveDoorLockKwikset_id="23629972-c861-4fcb-b374-4ab6bb74429a"
        self.zwaveDrape_id=""
        self.zwaveSoundbar_id=""
        self.zwaveSwitch_id=""
        self.zwaveThermostat_id=""
        self.tv_id=""
        self.waterSensor_id=""
#         self.zwaveEverspringSensor_id,
#         self.zwaveMultiSensor_id,
        

        self.long_string_id="123123i41o34dkfrqlekrjoqernqojr4q2o3j5oq2345jo234523o5j23o45j23ojfioq4hj523o45hj2nhtghoq24h2o345o9**(()";
        self.wrong_string_id1 = "d876cdc8-c582-4838-b065-d0eddddddddddd7frtrrrrrrrrrrrr8a7e75";
        self.wrong_string_id2 = "我爱中国我爱中国";
        self.wrong_string_id3 = "개발개발개발개발개발개발개발개발";
        self.wrong_string_id4 = "さまざまさまざまさまざま";
        self.null_string_id=""
        
        self.wrong_string_id_list=[self.long_string_id,self.wrong_string_id1,self.wrong_string_id2,self.wrong_string_id3,self.wrong_string_id4,self.null_string_id]
        
    def setUp(self):
        pass
     
     
    #=============================unpair===================================    
    
        
    '''     
    def FN_Device_aUnPair_001(self):
        self.logger.info("FN_Device_UnPair_002 :: test device unpair ----abnormal")
        finalValue=True
        for wrong_room_id in self.wrong_string_id_list: 
            res,resp=self.sendRst.getDeviceUnPair(wrong_room_id) 
            if(res.status ==200):
                self.logger.info(res.status)
                self.logger.info("respInfo:"+resp)
            else:
                finalValue=False
                self.logger.info("pair failure, room NO is :"+wrong_room_id)
        self.assertTrue(finalValue)
        
    '''
    '''   
    def FN_Device_aUnPair_002(self):
        self.logger.info("FN_Device_UnPair_001 :: test device UNpair ----normal")
        res,resp=self.sendRst.getDeviceUnPair(self.roomId,"on") 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp) 
      
'''    

     
    #=============================pair===================================
    def FN_Device_Pair_001(self):
        self.logger.info("FN_Device_UnPair_001 :: test device pair ----normal")
        res,resp=self.sendRst.getDevicePair(self.roomId,"On") 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp)
    

  
    
    '''  
    def FN_Device_Pair_002(self):
        self.info("FN_Device_UnPair_001 :: test device pair ----abnormal")
        finalValue=True
        for wrong_room_id in self.wrong_string_id_list: 
            res,resp=self.sendRst.getDevicePair(wrong_room_id) 
            if(res.status ==200):
                self.logger.info(res.status)
                self.logger.info("respInfo:"+resp)
            else:
                finalValue=False
                self.logger.info("pair failure, room NO is :"+wrong_room_id)
        self.assertTrue(finalValue)
       
    
    #=============================singlepair===================================        
    def FN_Device_Singlepair_001(self):
        self.logger.info("FN_Device_Singlepair_001 :: test device single pair ----normal")
        res,resp=self.sendRst.getDeviceSinglepair(self.roomId,"60","20","30") 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp)   
    
    
    #=============================StopPair===================================        
    def FN_Device_StopPair_001(self):
        self.logger.info("FN_Device_StopPair_001 :: test  StopPair ----normal")
        res,resp=self.sendRst.getDeviceStopPair(self.roomId) 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp) 
    
  
    #=============================multiplepair===================================        
    def FN_Device_Multiplepair_001(self):
        self.logger.info("FN_Device_Multiplepair_001 :: test device Multiplepair ----normal")
        res,resp=self.sendRst.getDeviceMultiplepair(self.roomId,"100") 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp) 
    

    #=============================DelPairDevice===================================        
    def FN_Device_DelPairDevice_001(self):
        self.logger.info("FN_Device_DelPairDevice_001 :: test del pair device ----normal")
        res,resp=self.sendRst.getDelPairDevice(self.roomId,self.zwaveDoorLockKwikset_id) 
        self.logger.info(res.status)
        self.logger.info("respInfo:"+resp) 
    '''