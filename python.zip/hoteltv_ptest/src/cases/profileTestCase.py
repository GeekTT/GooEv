# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
import json

class TC_Profile(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("profile")
        
        self.building_No=""
        self.floor_No=""
        self.room_No="0004-74df2a0d-0622-40c1-af91-378c4e395146"
        
        
        self.long_string_id="123123i41o34dkfrqlekrjoqernqojr4q2o3j5oq2345jo234523o5j23o45j23ojfioq4hj523o45hj2nhtghoq24h2o345o9**(()";
        self.wrong_string_id1 = "d876cdc8-c582-4838-b065-d0eddddddddddd7frtrrrrrrrrrrrr8a7e75";
        self.wrong_string_id2 = "我爱中国我爱中国";
        self.wrong_string_id3 = "개발개발개발개발개발개발개발개발";
        self.wrong_string_id4 = "さまざまさまざまさまざま";
        self.null_string_id=""
        
        self.wrong_string_id_list=[self.long_string_id,self.wrong_string_id1,self.wrong_string_id2,self.wrong_string_id3,self.wrong_string_id4,self.null_string_id]
        
    def setUp(self):
        pass
    
    #=============================Profile===================================
    def FN_getProfile_001(self):
        self.logger.info("FN_getProfile_001 :: test  profile ----normal")
        setres,setresp=self.sendRst.setProfileControl(self.room_No) 
        print setres.status,setresp
#         res,resp=self.sendRst.getProfileControl(self.room_No) 
#         self.logger.info("respInfo:"+resp)
#         rs=json.loads(resp)
#         if(res.status== 201):
#             self.assertEqual(rs["Description"], "Created", )
#         else:
#             self.assertEqual(res.status ,201 )
        
    '''
    def FN_getProfile_004(self):
        self.logger.info("FN_getProfile_003 :: test  profile ----abnormal with room_no")
        finalValue=True
        for wrong_room_no in self.wrong_string_id_list:
            res,resp=self.sendRst.getProfileControl(wrong_room_no) 
            self.logger.info("respInfo:"+resp)
            rs=json.loads(resp)
            if(res.status== 201):
                finalValue=False
        self.assertTrue(finalValue)
        
    '''