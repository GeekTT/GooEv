# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
from registerInfo import RegisterInfoClass
import json

class TC_Register(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("register")
        self.regInfo=RegisterInfoClass()
        
    def setUp(self):
        pass
    
    #=============================GW register===================================
    def FN_GW_Register_001(self):
        self.logger.info("FN_GW_Register_001 :: test gw register ----normal")
        registerInfo=self.regInfo.postGWRegister()
        print registerInfo
        res,resp=self.sendRst.postXMPPRegister(registerInfo) 
        self.logger.info("respInfo:"+resp)
        print res.status
        rs=json.loads(resp)
        if(res.status== 201):
            self.assertEqual(rs["Description"], "Created", )
        else:
            self.assertEqual(res.status ,201 )
        
    