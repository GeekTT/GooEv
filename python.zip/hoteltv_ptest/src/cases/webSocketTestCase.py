# coding=utf-8
'''
Created on Feb 12, 2014

@author: huanghuan
'''

import unittest
from hoteltvLogConfig import logConfigClass
from sendRequest import SendRequest
from resourceURIInfo import ResourceURLInfoClass 
import json

class TC_WebSocket(unittest.TestCase):
    
    
    @classmethod
    def setUpClass(self):
        self.sendRst=SendRequest()
        self.lConfig=logConfigClass()
        self.logger=self.lConfig.getChildLog("webSocket")
        self.rURIInfo=ResourceURLInfoClass()
        
    def setUp(self):
        pass
    
    #=============================post subscription===================================
    def FN_Subscription_001(self):
        self.logger.info("FN_Subscription_001 :: test post subscription ----normal")
        rURIInfo=self.rURIInfo.postRURIs()
        print rURIInfo
        res,resp=self.sendRst.postSubscriptions(rURIInfo) 
        for item in res.getheaders():
            if item[0]=='location':
                print item[1]
        self.assertEqual(res.status ,201 )
        
    