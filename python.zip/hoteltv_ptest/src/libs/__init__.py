'''
Created on Mar 24, 2013

@author: huanghuan
'''
import sys


if not "libs" in sys.path:
    sys.path.append("libs") 
    
if not "config" in sys.path:
    sys.path.append("config") 