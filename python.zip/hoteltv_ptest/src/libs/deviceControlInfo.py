'''
Created on Mar 12, 2014

@author: huanghuan
'''
import json
from hoteltvUtil import uitlClass
import time

class DeviceControlInfoClass():
    

        
    def __init__(self):
        
        self.util_class=uitlClass()
        
        DeviceControlInfoClass.dimmingLevelInfo=json.loads(self.util_class.getDimmingLevelInfo())
        DeviceControlInfoClass.powerStatuslInfo=json.loads(self.util_class.getPowerStatusInfo())
        DeviceControlInfoClass.doorLockInfo=json.loads(self.util_class.getDoorLockInfo())
        DeviceControlInfoClass.temperatureInfo=json.loads(self.util_class.getTemperatureInfo())
        DeviceControlInfoClass.windInfo=json.loads(self.util_class.getWindInfo())
        DeviceControlInfoClass.levelInfo=json.loads(self.util_class.getLevelInfo())
        DeviceControlInfoClass.unpairInfo=json.loads(self.util_class.getUnpairInfo())
        print DeviceControlInfoClass.unpairInfo
        
        DeviceControlInfoClass.dimmingLevelInfo["dimmingLevel"]=10
        DeviceControlInfoClass.powerStatuslInfo["power"]="On"
        DeviceControlInfoClass.doorLockInfo["lock"]="Lock"
        DeviceControlInfoClass.temperatureInfo["desired"]=3
        
        DeviceControlInfoClass.windInfo["direction"]="Auto"
        DeviceControlInfoClass.windInfo["speedLevel"]=10
        DeviceControlInfoClass.levelInfo["increment"]=10
        
        DeviceControlInfoClass.unpairInfo["discovery"]["action"]="Start"
        DeviceControlInfoClass.unpairInfo["discovery"]["type"]="SinglePairing"
        DeviceControlInfoClass.unpairInfo["discovery"]["timeout"]=60
                                           
    #######################  post GWregister info ######################  
    
    def putUnpairingInfo(self):
        data = json.dumps(DeviceControlInfoClass.unpairInfo,separators=(',',':'))
        return data
    
    def putDimmingLevel(self,level): 
        if(level!=""):
            DeviceControlInfoClass.dimmingLevelInfo["dimmingLevel"]=level
        data = json.dumps(DeviceControlInfoClass.dimmingLevelInfo,separators=(',',':'))
        return data
    
    def putpowerStatuslInfo(self,operation): 
        if(operation!=""):
            DeviceControlInfoClass.powerStatuslInfo["power"]=operation
        data = json.dumps(DeviceControlInfoClass.powerStatuslInfo,separators=(',',':'))
        return data
    
    def putdoorLockInfo(self,doorLock): 
        if(doorLock!=""):
            DeviceControlInfoClass.doorLockInfo["lock"]=doorLock
        data = json.dumps(DeviceControlInfoClass.doorLockInfo,separators=(',',':'))
        return data
    
    def putlevelInfo(self,level): 
        if(level!=""):
            DeviceControlInfoClass.levelInfo["increment"]=level
        data = json.dumps(DeviceControlInfoClass.levelInfo,separators=(',',':'))
        return data
    
    
    def puttemperatureInfo(self,desired): 
        if(desired!=""):
            DeviceControlInfoClass.temperatureInfo["desired"]=desired
        data = json.dumps(DeviceControlInfoClass.temperatureInfo,separators=(',',':'))
        return data
    
    def putwindInfo_Direction(self,direction): 
        if(direction!=""):
            DeviceControlInfoClass.windInfo["desired"]=direction
        data = json.dumps(DeviceControlInfoClass.windInfo,separators=(',',':'))
        return data
    
    def putwindInfo_SpeedLevel(self,speedLevel): 
        if(speedLevel!=""):
            DeviceControlInfoClass.windInfo["speedLevel"]=speedLevel
        data = json.dumps(DeviceControlInfoClass.windInfo,separators=(',',':'))
        return data