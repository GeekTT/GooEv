'''
Created on Jan 29, 2013

@author: huanghuan
'''
import logging
import logging.config

class logConfigClass():
    count= 0
    logger=""
    
    
    def __init__(self):
        self.__class__.count += 1 
        
        
    def getMainLog(self):
        if(self.__class__.count  == 1):
            logging.config.fileConfig('../config/logging.conf')
            self.__class__.logger = logging.getLogger("SLEP Logs:")  
        return self.__class__.logger 
    
    
    def getChildLog(self,name):
            self.__class__.logger=logging.getLogger("SLEP Logs:").getChild(name)
            return self.__class__.logger
   
           
if __name__ == "__main__":
    logConfig=logConfigClass()
    logger=logConfig.getMainLog()
    logger.debug('debug message')
    logger.warn('warn message')
    
    print logConfig.count
    
    logConfig2=logConfigClass()
    logger2=logConfig2.getChildLog("ll")
    print logConfig.count
    logger2.info('info message')
    logger2.warn('warn message')
    