'''
Created on Jan 29, 2013

@author: huanghuan
'''
import ConfigParser
import httplib  
import time
import json
import datetime


class uitlClass(): 
    def __init__(self):
        self.configPath="../config/config.conf"
        pass

    def getSBSAddr(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        host=cf.get("serverconfig", "sbsIP")
        httpPort=cf.get("serverconfig", "sbsPort")
        return host,httpPort
    
    
    def getGW1Addr(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        host=cf.get("serverconfig", "gw1Host")
        httpPort=cf.get("serverconfig", "GW1Port")
        return host,httpPort
    
    def getGW2Addr(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        host=cf.get("serverconfig", "gw2Host")
        serverPort=cf.get("serverconfig", "GW2Port")
        return host,serverPort
    
    
    def getLoginAccount(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        account=cf.get("serverconfig", "account")
        password=cf.get("serverconfig", "password")
        return account,password
        
   
    def getHeaders(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        req_headers=cf.get("serverconfig", "req_headers")
        return req_headers
    


    def getGWRegisterInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        gwRegisterInfo=cf.get("serverconfig", "gwRegisterInfo")
        return gwRegisterInfo
 
    def getDimmingLevelInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        dimmingLevel=cf.get("serverconfig", "dimmingLevel")
        return dimmingLevel
    
    def getPowerStatusInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        powerStatus=cf.get("serverconfig", "powerStatus")
        return powerStatus
    
    def getDoorLockInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        doorLock=cf.get("serverconfig", "doorLock")
        return doorLock
    
    
    def getResourceURIInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        resourceURIInfo=cf.get("serverconfig", "resourceURIInfo")
        return resourceURIInfo
    
    
    def getTemperatureInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        temperatureInfo=cf.get("serverconfig", "temperatureInfo")
        return temperatureInfo
    
    def getWindInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        windInfo=cf.get("serverconfig", "windInfo")
        return windInfo
        
    def getLevelInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        levelInfo=cf.get("serverconfig", "level")
        return levelInfo 
    
    def getUnpairInfo(self):
        cf = ConfigParser.RawConfigParser()
        cf.read(self.configPath)  
        unpairInfo=cf.get("serverconfig", "unpairInfo")
        return unpairInfo 
    
    
if __name__ == '__main__':  
    uc=uitlClass()
    user_id,authtoken=uc.getLoginAccount()
    print (type(user_id))
    print (type(authtoken))
    print uc.getLoginSessionId(user_id,authtoken)
    #res,resp=uc.getRequest('GET',sID,'/modes')
    #print resp
    #print uc.getModeXMLPath()
    #uc.scpModeFiles()
    #uc.scpDeviceFiles()
    
    