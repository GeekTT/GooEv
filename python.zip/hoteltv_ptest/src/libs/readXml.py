'''
Created on Mar 20, 2013

@author: huanghuan
'''
from slepUtil import uitlClass
import xml.dom.minidom

class ReadXml():
    
    def __init__(self):
        self.util_class=uitlClass()
        
    def parsexml(self,filepath):
        '''
        f = codecs.open(xmlfile, "r", "utf-8")
        text=f.read()
        #print text
        f.close()
        return xml.dom.minidom.parseString(text)
        '''
        return xml.dom.minidom.parse(filepath)
        
    
    def get_attrvalue(self,node, attrname):
        return node.getAttribute(attrname) if node else ''
    
    
    def get_nodevalue(self,node, index = 0):
        return node.childNodes[index].nodeValue if node else ''
    
    def get_xmlnode(self,node,name):
        return node.getElementsByTagName(name) if node else []