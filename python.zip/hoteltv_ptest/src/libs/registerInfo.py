'''
Created on Mar 12, 2014

@author: huanghuan
'''
import json
from hoteltvUtil import uitlClass
import time

class RegisterInfoClass():
    

        
    def __init__(self):
        
        self.util_class=uitlClass()
        
        RegisterInfoClass.gwRegisterInfo=json.loads(self.util_class.getGWRegisterInfo())
        
        
        RegisterInfoClass.gwRegisterInfo["RoomNumber"]["BuildingNo"]="A1"
        RegisterInfoClass.gwRegisterInfo["RoomNumber"]["FloorNo"]="1"
        RegisterInfoClass.gwRegisterInfo["RoomNumber"]["RoomNo"]="104"  #room_no in table room_tbl
        RegisterInfoClass.gwRegisterInfo["SbsServer"]["ip"]="109.123.112.107"
        RegisterInfoClass.gwRegisterInfo["SbsServer"]["port"]="8080"
        
    #######################  post GWregister info ######################  
    
    def postGWRegister(self): 
        data = json.dumps(RegisterInfoClass.gwRegisterInfo,separators=(',',':'))
        return data