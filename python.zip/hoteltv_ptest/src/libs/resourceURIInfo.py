'''
Created on Mar 12, 2014

@author: huanghuan
'''
import json
from hoteltvUtil import uitlClass
import time

class ResourceURLInfoClass():
    

        
    def __init__(self):
        
        self.util_class=uitlClass()
        
        ResourceURLInfoClass.resourceURIInfo=json.loads(self.util_class.getResourceURIInfo())
        #print type(ResourceURLInfoClass.resourceURIInfo)
        
        rURIlist=[]
        rURIlist.append("/*?id=530e8400-e29b-41d4-a716-446655440001&resourceType=Alarm")
        rURIlist.append("/*?id=101&resourceType=Room")   #set current room id
        rURIlist.append("/*?id=530e8400-e29b-41d4-a716-446655440001&resourceType=Device")
        ResourceURLInfoClass.resourceURIInfo["resourceURIs"]=rURIlist
        
    #######################  post GWregister info ######################  
    
    def postRURIs(self): 
        
        data = json.dumps(ResourceURLInfoClass.resourceURIInfo,separators=(',',':'))
        print type(data)
        return data
    
