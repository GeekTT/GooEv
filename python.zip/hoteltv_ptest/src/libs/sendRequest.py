'''
Created on Apr 25, 2013

@author: huanghuan
'''
from hoteltvUtil import uitlClass
import httplib
import time
import json

class SendRequest():
    user_sessionId=""
    req_headers=""
    
    def __init__(self):
        self.uClass=uitlClass()
        self.sbsHost,self.sbsPort=self.uClass.getSBSAddr()
        self.gw1Host,self.gw1Port=self.uClass.getGW1Addr()
        self.gw2Host,self.gw2Port=self.uClass.getGW2Addr()
        self.req_headers=eval(self.uClass.getHeaders())
        self.baseUrl="/sbs-presentation"

        
        
################################### login and get session_id ################################   
    def getRequest(self,host,port,req_method,req_url,data,req_headers,timeout=30):
        try:
            conn = httplib.HTTPConnection(host,port)
            if(data==None and req_headers!=None):
                conn.request(req_method, req_url, headers=req_headers)  
            elif(data !=None and req_headers ==None):
                conn.request(req_method, req_url,body=data)  
            else:
                conn.request(req_method, req_url,body=data,headers=req_headers)  
            res=conn.getresponse()
        except httplib.HTTPException as tmp:
            print tmp
        except Exception as tmp:
            print tmp
        else:
            resp=res.read()
            conn.close()
        return res,resp 
    
    
    def getLoginSessionId(self):
        if(SendRequest.user_sessionId==""):
            print(  "test login GW-" )
            account,password=self.uClass.getLoginAccount()
            request_body = """
                        {
                            "LoginPassword" : {
                                        "account": "%s",
                                        "password":  "%s"
                                      }
                        }
            """ % (account,password)
            
            print "GW port and ip",self.gw1Host,self.gw1Port
            res,resp=self.getRequest(self.gw1Host,int(self.gw1Port),'POST','/loginpassword'.encode('ascii'),request_body,None)
            
            try:
                r = json.loads(resp)
            except:
                r = None
            assert ('LoginPassword' in r)
            assert ('id' in r["LoginPassword"])
            assert ('session_id' in r["LoginPassword"])
            SendRequest.user_sessionId = r["LoginPassword"]["session_id"] 
            print "Login.user_sessionId:",SendRequest.user_sessionId
            print "login sucess"
            return SendRequest.user_sessionId
        
           
    
    def getHeadearsWithSession(self):
        SendRequest.req_headers=self.req_headers
        if(SendRequest.user_sessionId==""):
            self.getLoginSessionId()
        SendRequest.req_headers["x-api-sessionid"]=SendRequest.user_sessionId
        # When config.xml account without session
        #SendRequest.req_headers["x-api-sessionid"]=None   
#         print "SendRequest.req_headers:",SendRequest.req_headers
        return SendRequest.req_headers
    

        
################################### XMPPRegister ################################ 
    #url = '/grmsagent/network'   PUT    '/gateway/configuration'  'POST'
    def postXMPPRegister(self,data):
        res, resp = self.getRequest(self.gw1Host,int(self.gw1Port),'PUT',  '/room/network',data,self.getHeadearsWithSession())     
        time.sleep(1)
        return res,resp
    
################################## device UPair ################################ 
 
    def getDevicePair(self,roomID,startpair):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/pair?roomID='+roomID+"&startpair="+startpair,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    
    def getDeviceSinglepair(self,roomID,timeout,x_pos,y_pos):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/singlepair?roomID='+roomID+"&timeOut="+timeout+"&x_pos="+x_pos+"&y_pos="+y_pos,None,self.req_headers) 
        time.sleep(1)
        return res,resp
    
    
    def getDeviceMultiplepair(self,roomID,timeout):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/multiplepair?roomID='+roomID+"&timeOut="+timeout,None,self.req_headers)     
        time.sleep(1)
        return res,resp
  
    
    def getDeviceStopPair(self,roomID):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/stoppair?roomID='+roomID,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    
    def getDeviceUnPair(self,roomID,startunpair):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET', self.baseUrl+'/unpair?roomID='+roomID+"&startunpair="+startunpair,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    

    
    def getDeviceUnPair2(self,data):
        url=self.baseUrl+'/56bcc08b-ada1-4871-984a-4eaef3c52752/discovery'
        print url
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',url ,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    def getDelPairDevice(self,roomID,devId):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET', self.baseUrl+'/deletedevice?roomID='+roomID+"&deviceID="+devId ,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    
#     def getAssignDevice(self,roomNO,devId):
#         res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/deletedevice/pairwithdeviceid?RoomNo='+roomNO+"&DeviceId="+devId,None,self.req_headers)     
#         time.sleep(1)
#         return res,resp
#     
#     
#     def getUnAssignDevice(self,roomNO,devId):
#         res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/deletedevice/pairwithdeviceid?RoomNo='+roomNO+"&DeviceId="+devId,None,self.req_headers)     
#         time.sleep(1)
#         return res,resp
#     

################################## profile ################################ 
    def getProfileControl(self,room_No):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+'/getProfile?RoomNo='+room_No,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    def setProfileControl(self,room_No):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+'/setProfile?RoomNo='+room_No,None,self.req_headers)     
        time.sleep(1)
        return res,resp 
     
################################## subscriptions  ################################ 

    def postSubscriptions(self,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'POST',  self.baseUrl+'/subscriptions',data,self.req_headers)     
        time.sleep(1)
        return res,resp
    
################################## device control ################################ 

    def setDeviceStatus(self,device_id,device_type,operation):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+"/test/control?deviceId="+device_id+"&deviceType="+device_type+"&operation="+operation,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    
    def getDeviceStatus(self,device_id):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'GET',  self.baseUrl+"/"+device_id,None,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    def setDoorLock(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/door',data,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    def setDrape(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/level',data,self.req_headers)     
        time.sleep(1)
        return res,resp
    

    def setPowerStatus(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/operation',data,self.req_headers)     
        time.sleep(1)
        return res,resp
    
    
    def setDimmingLevel(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/light',data,self.req_headers)     
        time.sleep(1)
        return res,resp
  
    
    def setTemperature(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/temperature',data,self.req_headers)     
        time.sleep(1)
        return res,resp 
    
    
    def setWind(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/wind',data,self.req_headers)     
        time.sleep(1)
        return res,resp 
    
    
    def setLevel(self,device_id,data):
        res, resp = self.getRequest(self.sbsHost,int(self.sbsPort),'PUT',  self.baseUrl+device_id+'/level',data,self.req_headers)     
        time.sleep(1)
        return res,resp 