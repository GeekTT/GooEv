'''
Created on Apr 25, 2013

@author: huanghuan
'''
import json
from libs.hoteltvUtil import uitlClass
from libs.sendRequest import SendRequest

class Login():
    count= 0
    user_sessionId=""
    req_headers=""
    
    def __init__(self):
        Login.count+=1
        self.uClass=uitlClass()
        self.sendRst=SendRequest()
        Login.req_headers=eval(self.uClass.getHeaders())
        
    def getLoginSessionId(self):
        print(  "test loginpassword xx")
        account,password=self.uClass.getLoginAccount()
        print account,password
        request_body = """
                    {
                        "LoginPassword" : {
                                    "account": "%s",
                                    "password":  "%s"
                                  }
                    }
    """ % (account,password)
        res,resp=self.sendRst.getRequest("109.123.121.75",3115,'POST','/loginpassword'.encode('ascii'),request_body,None)
        print res.status
        print resp
        try:
            r = json.loads(resp)
            print r
        except:
            r = None
        assert ('LoginPassword' in r)
        assert ('id' in r["LoginPassword"])

        assert ('session_id' in r["LoginPassword"])
                
       

        Login.user_sessionId = r["LoginPassword"]["session_id"] 
        return Login.user_sessionId
        
    
    def getHeadears(self):
        #if(Login.count==1):
        print Login.user_sessionId
        if(Login.user_sessionId==""):
            self.getLoginSessionId()
            Login.req_headers=eval(self.uClass.getHeaders())
            Login.req_headers["x-api-sessionid"]=Login.user_sessionId
            print Login.req_headers["x-api-sessionid"]
        return Login.req_headers
      
if __name__ == '__main__':  
    login=Login()
    print login.getHeadears()
    