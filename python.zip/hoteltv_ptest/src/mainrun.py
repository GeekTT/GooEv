'''
Created on Feb 6, 2013

@author: huanghuan
'''
import unittest
import io
from libs.hoteltvLogConfig import logConfigClass
from cases.registerTestCase import TC_Register
from cases.profileTestCase import TC_Profile
from cases.deviceUPairTestCase import TC_DevUPair
from cases.deviceControl2TestCase import TC_DevControl
from cases.webSocketTestCase import TC_WebSocket


def registerSuite():
    return unittest.makeSuite(TC_Register, "FN")

def upairSuite():
    return unittest.makeSuite(TC_DevUPair, "FN")

def profileSuite():
    return unittest.makeSuite(TC_Profile, "FN")

def deviceControlSuite():
    return unittest.makeSuite(TC_DevControl, "FN")

def webSocketSuite():
    return unittest.makeSuite(TC_WebSocket, "FN")

# def buildTestSuite():
#     suite = unittest.TestSuite()
#     suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TC_ServiceDeviceManager))
#     return suite

           
if __name__ == '__main__':
    logConfig=logConfigClass()
    logger=logConfig.getMainLog()  
    execout = io.BytesIO()
    
    suit_register=registerSuite()
    suit_upair=upairSuite()
    suite_profile=profileSuite()
    suit_deviceControl=deviceControlSuite()
    suit_webSocket=webSocketSuite()
    
    alltests = unittest.TestSuite((
#                                        suit_register
                                                suit_upair
#                                                suite_profile,
 #                                               suit_deviceControl
#                                                  suit_webSocket
                                                ))
    
    
    unittest.TextTestRunner(execout,verbosity=2).run(alltests)
    sout=execout.getvalue()
    logger.info(sout) 
    
    f = open('../report/result.txt', 'w')
    f.write(sout)
    f.close()
#     input('Pls. input any key to exit!')
    

