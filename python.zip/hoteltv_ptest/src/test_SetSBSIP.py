import httplib
import json
import urllib
import time
import itertools
import ast

###############################################
# To run this script, Please set the following parameters:
#################################################
server_ip = '109.123.121.75'
server_port = 3213


account_1 = 'beyonceslep@gmail.com'
account_2 = 'bredslep@gmail.com'
authcode = '1234'  # issues a code via OSP server.
password = '1234'

user_info_1 = {"id":"", "SessionId":""}
user_info_2 = {"id":"", "SessionId":""}

conn = None
session_id = None

def setup_func():
    "set up test fixtures"
    global server_ip
    global server_port
    global conn
    conn = httplib.HTTPConnection(server_ip, server_port, timeout=30)

def teardown_func():
    "tear down test fixtures"

def get_json_response(url, method, query_params, request_body):
    global conn
    global session_id
    if query_params:
        params = urllib.urlencode(query_params)
        url = url + "?" + params

    req_headers = {'x-api-sessionid': session_id}

    conn.request(method, url.encode('ascii'), request_body, req_headers)

    print 'Making request:', method, url.encode('ascii'), request_body

    y= conn.getresponse()
    print 'response status is :', y.status

    if session_id == None :
        session_id = y.getheader("X-SLE-SessionId")

    return y

def parse_json(y):
    z = y.read()  # get the json response string
    try:
        z1 = json.loads(z)  # convert json response to equivalent python data structure
    except:
        z1 = None
    return z1

def test_loginpassword(account, password):
    global conn
    global session_id
    print   "test loginpassword"
    request_body = """{"LoginPassword" : {"account": "%s","password":  "%s"}}""" % (account,password)
    print request_body
    setup_func()
    conn.request('PUT','/loginpassword'.encode('ascii'),request_body)
    y = conn.getresponse()
    z1 = y.read()
    print z1

    try:
        r = json.loads(z1)
    except:
        r = None
    assert ('LoginPassword' in r)
    
    assert ('id' in r["LoginPassword"])

    print "id = ", r["LoginPassword"]["id"]

    assert ('session_id' in r["LoginPassword"])
    assert (len(r["LoginPassword"]["session_id"]))
    print "session_id = ", r["LoginPassword"]["session_id"]
    session_id = r["LoginPassword"]["session_id"]
'''	
    if account == account_1:
        user_info_1['id'] = r["LoginPassword"]["id"]
        user_info_1['SessionId'] = r["LoginPassword"]["session_id"]
    else:
        user_info_2['id'] = r["LoginPassword"]["id"]
        user_info_2['SessionId'] = r["Logi
        nPassword"]["session_id"]
'''

def test_set_grms_server_ip_and_room_number():
    print ' '
    print 'testing test_set_grms_server_ip_and_room_number'

    url = '/room/network'
    request_body = """{"RoomNumber": { "BuildingNo": "D2","FloorNo": "5","RoomNo": "319"},"SbsServer" : {"ip" : "109.123.112.170","port" : "8080"}}"""
    r = get_json_response(url,'PUT',None, request_body)
    y = parse_json(r)
    print ' the response body is::: ', y
    print 'the response code is:: ', r.status
    print 'Exiting test_set_grms_server_ip_and_room_number '
    return

if __name__ == "__main__":
    import sys

    print '******************Monitoring test begin : ********************************'
    try:
        test_loginpassword(account_2, password)
        test_set_grms_server_ip_and_room_number()
        print '***************Finished testing GrmsAgent module***********************'
    except Exception, err:
        print err
        sys.exit(-1)
    sys.exit(0)
